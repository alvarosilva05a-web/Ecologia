import React from 'react';
import { CalculationResult, Category } from '../types';

interface MatrixTableProps {
  data: CalculationResult;
}

const MatrixTable: React.FC<MatrixTableProps> = ({ data }) => {
  return (
    <div className="overflow-hidden bg-white rounded-2xl shadow-xl border border-indigo-100 mb-8 font-sans">
      <div className="p-5 bg-gradient-to-r from-indigo-900 to-violet-800 text-white font-bold text-center text-lg tracking-wide">
        7. Matriz de Resultados Académicos
      </div>
      
      {/* Table 1: General Indicators */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-slate-700">
          <thead className="text-xs text-indigo-100 uppercase bg-slate-900">
            <tr>
              <th className="px-6 py-4 font-bold tracking-wider w-1/3">Indicador</th>
              <th className="px-6 py-4 text-center">Referencia Media</th>
              <th className="px-6 py-4 text-center bg-cyan-500/20 text-cyan-300 font-bold border-x border-slate-700">
                Est. 1 (Tú)
              </th>
              {/* Empty columns for other students as per image */}
              <th className="px-6 py-4 text-center hidden md:table-cell text-slate-500">Est. 2</th>
              <th className="px-6 py-4 text-center hidden md:table-cell text-slate-500">Est. 3</th>
              <th className="px-6 py-4 text-center hidden md:table-cell text-slate-500">Est. 4</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-semibold text-slate-800">Huella Ecológica Total (gha/persona)</td>
              <td className="px-6 py-4 text-center text-slate-500">2.7 gha</td>
              <td className="px-6 py-4 text-center font-bold text-indigo-700 bg-indigo-50/50">{data.totalGha}</td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
            </tr>
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-semibold text-slate-800">Número de "Tierras" (Planetas necesarios)</td>
              <td className="px-6 py-4 text-center text-slate-500">1.7</td>
              <td className="px-6 py-4 text-center font-bold text-indigo-700 bg-indigo-50/50">{data.numberEarths}</td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
            </tr>
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-semibold text-slate-800">Día de Sobrecapacidad (Día y Mes)</td>
              <td className="px-6 py-4 text-center text-slate-500">2 Ago</td>
              <td className="px-6 py-4 text-center font-bold text-indigo-700 bg-indigo-50/50">{data.overshootDate}</td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
            </tr>
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-semibold text-slate-800">Huella de Carbono (tCO2/año)</td>
              <td className="px-6 py-4 text-center text-slate-500">≈ 4.7 t</td>
              <td className="px-6 py-4 text-center font-bold text-indigo-700 bg-indigo-50/50">{data.carbonFootprint}</td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
              <td className="px-6 py-4 hidden md:table-cell"></td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="h-1 bg-gradient-to-r from-transparent via-slate-200 to-transparent"></div>

      {/* Table 2: Breakdown */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-slate-700">
          <thead className="text-xs text-indigo-100 uppercase bg-slate-900">
            <tr>
              <th className="px-6 py-4 font-bold tracking-wider w-1/3">Categoría (en gha)</th>
              <th className="px-6 py-4 text-center bg-cyan-500/20 text-cyan-300 font-bold border-x border-slate-700">
                Est. 1 (Tú)
              </th>
              <th className="px-6 py-4 text-center hidden md:table-cell text-slate-500">Est. 2</th>
              <th className="px-6 py-4 text-center hidden md:table-cell text-slate-500">Est. 3</th>
              <th className="px-6 py-4 text-center hidden md:table-cell text-slate-500">Est. 4</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-medium text-slate-700">Alimentación</td>
              <td className="px-6 py-4 text-center bg-indigo-50/50 font-semibold text-slate-800">{data.breakdown[Category.FOOD]}</td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
            </tr>
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-medium text-slate-700">Vivienda</td>
              <td className="px-6 py-4 text-center bg-indigo-50/50 font-semibold text-slate-800">{data.breakdown[Category.HOUSING]}</td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
            </tr>
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-medium text-slate-700">Transporte (Movilidad)</td>
              <td className="px-6 py-4 text-center bg-indigo-50/50 font-semibold text-slate-800">{data.breakdown[Category.TRANSPORT]}</td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
            </tr>
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-medium text-slate-700">Bienes</td>
              <td className="px-6 py-4 text-center bg-indigo-50/50 font-semibold text-slate-800">{data.breakdown[Category.GOODS]}</td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
            </tr>
            <tr className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 font-medium text-slate-700">Servicios</td>
              <td className="px-6 py-4 text-center bg-indigo-50/50 font-semibold text-slate-800">{data.breakdown[Category.SERVICES]}</td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
              <td className="hidden md:table-cell"></td>
            </tr>
            <tr className="bg-indigo-600 text-white font-bold">
              <td className="px-6 py-4 border-r border-indigo-500">TOTAL (gha)</td>
              <td className="px-6 py-4 text-center text-white text-lg">{data.totalGha}</td>
              <td className="hidden md:table-cell border-r border-indigo-500"></td>
              <td className="hidden md:table-cell border-r border-indigo-500"></td>
              <td className="hidden md:table-cell"></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MatrixTable;