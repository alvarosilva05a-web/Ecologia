import { GoogleGenAI } from "@google/genai";
import { CalculationResult, StudentProfile } from "../types";

export const getAiRecommendations = async (result: CalculationResult, profile: StudentProfile) => {
  let apiKey: string | undefined;

  try {
    apiKey = process.env.API_KEY;
  } catch (error) {
    console.warn("Could not access process.env.API_KEY");
  }

  if (!apiKey) {
    return `Estudiante: ${profile.name} | Código: ${profile.studentCode}\nEscuela Profesional: ${profile.professionalSchool} | UNSAAC\n\nNota: Para ver el análisis detallado del profesor virtual, se requiere una clave API configurada.`;
  }

  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    Rol: Eres el MSc. Alvaro Christiam Silva Espejo, docente del curso "Ecología y Medio Ambiente" en la UNSAAC (Cusco, Perú).
    
    Instrucción CRÍTICA DE FORMATO: 
    Tu respuesta DEBE comenzar OBLIGATORIAMENTE con la siguiente línea exacta (reemplazando los datos):
    "Estudiante: [Nombre del Estudiante] | Código: [Código] | Semestre: [Ciclo] | Escuela: [Escuela Profesional]"
    
    Tarea: Analizar la Huella de Carbono del estudiante y dar recomendaciones.

    Datos del Estudiante:
    - Nombre: ${profile.name}
    - Código: ${profile.studentCode}
    - Escuela: ${profile.professionalSchool}
    - Ciclo: ${profile.courseCycle}
    
    Resultados:
    - Huella Ecológica: ${result.totalGha} gha (Media Perú: 1.6 gha)
    - Planetas: ${result.numberEarths}
    - CO2: ${result.carbonFootprint} t/año
    - Desglose: ${JSON.stringify(result.breakdown)}
    
    Estructura del cuerpo del informe (después de la línea de estudiante):
    1. DIAGNÓSTICO: ¿Es sostenible? Comparar con media peruana (1.6 gha).
    2. ANÁLISIS: Identifica qué categoría (Alimentación, Transporte, etc.) es la más alta y por qué.
    3. ACCIONES UNSAAC: 3 acciones concretas para realizar en Cusco o en la ciudad universitaria.
    4. REFLEXIÓN FINAL: Breve mensaje ético.

    Tono: Académico, estricto pero constructivo. No uses markdown de encabezados (###), usa NEGRITAS para resaltar títulos.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating AI content:", error);
    return `Estudiante: ${profile.name} | Código: ${profile.studentCode}\n\nError al generar el análisis. Por favor intente nuevamente.`;
  }
};