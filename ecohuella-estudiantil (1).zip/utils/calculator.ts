import { QuizState, CalculationResult, Category } from '../types';
import { QUESTIONS, BIOCAPACITY_PER_PERSON } from '../constants';

export const calculateFootprint = (answers: QuizState): CalculationResult => {
  // Initialize breakdown
  const breakdown: Record<Category, number> = {
    [Category.FOOD]: 0,
    [Category.HOUSING]: 0,
    [Category.TRANSPORT]: 0,
    [Category.GOODS]: 0,
    [Category.SERVICES]: 0,
  };

  // Base Logic: 
  // Each question option has a 'value' which represents a partial contribution to the GHA.
  // We simply sum these up per category.
  // We add a small 'baseline' constant to each category to account for shared infrastructure 
  // that exists regardless of individual choice (e.g., roads, government services).

  const BASELINE_INFRASTRUCTURE: Record<Category, number> = {
    [Category.FOOD]: 0.1,
    [Category.HOUSING]: 0.1,
    [Category.TRANSPORT]: 0.1,
    [Category.GOODS]: 0.1,
    [Category.SERVICES]: 0.2, // Public services, military, etc.
  };

  // 1. Apply Baseline
  Object.keys(breakdown).forEach(key => {
    breakdown[key as Category] += BASELINE_INFRASTRUCTURE[key as Category];
  });

  // 2. Add User Answers
  QUESTIONS.forEach((q) => {
    const answerValue = answers[q.id] || 0;
    breakdown[q.category] += answerValue;
  });

  // Calculate Total GHA
  const totalGha = Object.values(breakdown).reduce((sum, val) => sum + val, 0);

  // Calculate Earths
  const numberEarths = totalGha / BIOCAPACITY_PER_PERSON;

  // Calculate Carbon Footprint
  // Approximate conversion: In many footprints, carbon is ~60% of the total footprint.
  // 1 gha ~ 1.5 - 2.5 tonnes CO2 depending on the country mix.
  // We will use a multiplier of 2.1 for this academic context.
  const carbonFootprint = totalGha * 2.1;

  // Calculate Overshoot Day
  let overshootDate = "N/A (Sostenible)";
  if (totalGha > BIOCAPACITY_PER_PERSON) {
    const dayOfYear = Math.round((365 * BIOCAPACITY_PER_PERSON) / totalGha);
    // Create date for current year
    const date = new Date(new Date().getFullYear(), 0, dayOfYear);
    overshootDate = date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
  }

  return {
    totalGha: parseFloat(totalGha.toFixed(2)),
    numberEarths: parseFloat(numberEarths.toFixed(2)),
    overshootDate,
    carbonFootprint: parseFloat(carbonFootprint.toFixed(1)),
    breakdown: {
      [Category.FOOD]: parseFloat(breakdown[Category.FOOD].toFixed(2)),
      [Category.HOUSING]: parseFloat(breakdown[Category.HOUSING].toFixed(2)),
      [Category.TRANSPORT]: parseFloat(breakdown[Category.TRANSPORT].toFixed(2)),
      [Category.GOODS]: parseFloat(breakdown[Category.GOODS].toFixed(2)),
      [Category.SERVICES]: parseFloat(breakdown[Category.SERVICES].toFixed(2)),
    }
  };
};